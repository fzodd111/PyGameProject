import pygame
from f_load_image import load_image

SP = [(pygame.transform.scale(load_image("knife/knife.png"), (1, 1)),  pygame.Rect(0, 0, 1, 1))]
SIZE = width, height = 1366, 768
SCREEN = pygame.display.set_mode(SIZE)


def inventory(z=0, x=None, y=None):
    # Функция, отвечающая за инвентарь игрока
    global SP
    if x != None and y != None and ((x, y) not in SP):
        SP.append((x, y))
    if z < len(SP):
        return SP[z][0], SP[z][1]
    else:
        return SP[0][0], SP[0][1]


inventory()