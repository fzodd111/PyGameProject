import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN
from f_sp_fragments import SP_FRAGMENTS

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def third_room():
    # Функция, отвечающая за 2 комнату

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN
    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображений стен
    sp_images_walls = [pygame.transform.scale(load_image("third_room/1_3.png"), size),
                       pygame.transform.scale(load_image("third_room/2_3.png"), size),
                       pygame.transform.scale(load_image("third_room/4_3.png"), size),
                       pygame.transform.scale(load_image("third_room/3_3.png"), size)]
    # Индекс и список, отвечающий за фон
    index_wall = 0
    background = sp_images_walls[index_wall]

    # Индекс и список, отвечающий за номер фона
    sp_number_wall = [0, 1, 2, 3]
    background_number = sp_number_wall[index_wall]

    # Загрузка изображений стрелок
    sp_images_arrow = [pygame.transform.scale(load_image("arrow/arrow_left.png"), (50, 50)),
                       pygame.transform.scale(load_image("arrow/arrow_right.png"), (50, 50))]

    # Создание непрозрачных прямоугольников для стрелок
    sp_rectangle_arrow = [pygame.Rect(10, (height - 50) // 2, 30, 50),
                          pygame.Rect(width - 40, (height - 50) // 2, 30, 50)]

    for i in sp_rectangle_arrow:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    def zero_wall():
        sp_transition0 = [pygame.Rect(width * 71 // 100, height * 58.5 // 100,
                                     width * 9.5 // 100, height * 15.6 // 100),
                         pygame.Rect(width * 18.3 // 100, height * 65 // 100,
                                     width * 16.8 // 100, height * 14.3 // 100)
                         ]

        for i in sp_transition0:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition0[0].collidepoint(event.pos):
                    # Перемещение в окно с сейфом для второй комнаты
                    import f_safe_third_room
                    f_safe_third_room.safe_third_room()
                if sp_transition0[1].collidepoint(event.pos):
                    # Перемещение в окно с ящиком для 3 комнаты
                    import f_box_third_room
                    f_box_third_room.box_third_room()

    def first_wall():
        screen.blit(pygame.transform.scale(load_image("third_room/c_small_third_room.png"), (width * 5.8 // 100,
                                                                                             height * 10.4 // 100)),
                    (width * 65.8 // 100, height * 52 // 100))

        sp_transition = [pygame.Rect(width * 65.8 // 100, height * 52 // 100,
                                     width * 5.8 // 100, height * 10.4 // 100)
                         ]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение в окно с кодом для 3 комнаты
                    import f_c_third_room
                    f_c_third_room.c_third_room()

    def second_wall():
        screen.blit(pygame.transform.scale(load_image("third_room/pot.png"), (width * 16.8 // 100,
                                                                              height * 16.9 // 100)),
                    (width * 49.7 // 100, height * 46.8 // 100))

        sp_transition = [pygame.Rect(width * 74.6 // 100, height * 29.2 // 100,
                                     width * 6.9 // 100, height * 15.6 // 100),
                         pygame.Rect(width * 90 // 100, 0,
                                     width * 2.9 // 100, height * 10.4 // 100)
                         ]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение в окно "выбор комнат"
                    import f_choice_level
                    f_choice_level.choice_level()
                if sp_transition[1].collidepoint(event.pos):
                    # Перемещение в окно для взаимодействия со спичками
                    import f_matches
                    f_matches.matches()

    def third_wall():
        sp_transition = [pygame.Rect(width * 19.7 // 100, height * 24.7 // 100,
                                     width * 6.9 // 100, height * 15.6 // 100)
                         ]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Создание текста
                    text_color = (255, 255, 255)
                    font = pygame.font.Font(None, 40)  # None - системный шрифт, 74 - размер шрифта
                    text_surface = font.render('Недостаточно фрагментов картины', True, text_color)
                    text_rect = (0, 0, width * 7.3 // 100, height * 6.5 // 100)

                    if len(SP_FRAGMENTS) == 3:
                        # Перемещение в окно для сборки финальной картинки
                        import f_final
                        f_final.final()
                    else:
                        screen.blit(text_surface, text_rect)

    pygame.display.set_caption('Room')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    # Смена стен в левую сторону
                    if sp_rectangle_arrow[0].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall - 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall - 1) % len(sp_number_wall)]
                        index_wall -= 1
                    # Смена стен в правую сторону
                    if sp_rectangle_arrow[1].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall + 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall + 1) % len(sp_number_wall)]
                        index_wall += 1

        # Отображение стены
        screen.blit(background, (0, 0))
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        if background_number == 0:
            # Переход к функции, отвечающей за 0 стену
            zero_wall()
        elif background_number == 1:
            # Переход к функции, отвечающей за 1 стену
            first_wall()
        elif background_number == 2:
            # Переход к функции, отвечающей за 2 стену
            second_wall()
        elif background_number == 3:
            # Переход к функции, отвечающей за 3 стену
            third_wall()

        # Отображение изображений стрелок
        screen.blit(sp_images_arrow[0], (0, (height - 50) // 2))
        screen.blit(sp_images_arrow[1], (width - 50, (height - 50) // 2))

        # Отображение области для обработки нажатия на стрелку
        for i in sp_rectangle_arrow:
            screen.blit(surface, i.topleft)

        pygame.display.flip()
        clock.tick(fps)


third_room()