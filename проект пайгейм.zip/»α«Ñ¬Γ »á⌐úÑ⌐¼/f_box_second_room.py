import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN
import f_inventory
from f_sp_fragments import SP_MATCHES

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def box_second_room():
    global SP, SIZE, SCREEN
    # Функция, отвечающая за окно с кодом для второй комнаты

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN
    color = (255, 0, 0, 0)

    # Загрузка изображения фона
    sp_images = [pygame.transform.scale(load_image("menu/empty_box.png"), (width, height))]
    sp_positions_image = [(0, 0)]

    pygame.display.set_caption('Box_second_room')

    sp_button = [pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100),
                 pygame.Rect(width * 46.1 // 100, height * 26 // 100,
                             width * 9.5 // 100, height * 13 // 100)
                 ]

    fps = 30
    clock = pygame.time.Clock()
    if len(SP_MATCHES) == 0:
        flag = True
    else:
        flag = False

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_button[0].collidepoint(event.pos):
                        # Перемещение во 2 комнату
                        import f_second_room
                        f_second_room.second_room()
                    elif sp_button[1].collidepoint(event.pos):
                            # Взять спички
                            SP_MATCHES.append(1)
                            flag = False
                            x = pygame.transform.scale(load_image("third_room/matches.png"), (width * 5.8 // 100,
                                                                                              height * 10.4 // 100))
                            y = pygame.Rect(width * 88.9 // 100, 0,
                                            width * 0.73 // 100, height * 1.3 // 100)
                            f_inventory.inventory(1, x, y)

        screen.blit(sp_images[0], sp_positions_image[0])
        for i in sp_button:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)
        if flag:
            screen.blit(pygame.transform.scale(load_image("second_room/box.png"), (width * 10.9 // 100,
                                                                                   height * 13.6 // 100)),
                        (width * 45.3 // 100, height * 25.6 // 100))

        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        pygame.display.flip()
        clock.tick(fps)


box_second_room()