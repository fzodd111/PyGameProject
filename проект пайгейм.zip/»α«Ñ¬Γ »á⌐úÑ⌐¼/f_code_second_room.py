import pygame
import sys
from f_load_image import load_image


def code_second_room():
    # Функция, отвечающая за окно с кодом для второй комнаты

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    sp_images = [pygame.transform.scale(load_image("second_room/code_second_room.png"), (width, height))]
    sp_positions_image = [(0, 0)]
    screen.blit(sp_images[0], sp_positions_image[0])

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    pygame.display.set_caption('Code')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение во 2 комнату
                        import f_second_room
                        f_second_room.second_room()

        pygame.display.flip()
        clock.tick(fps)


code_second_room()