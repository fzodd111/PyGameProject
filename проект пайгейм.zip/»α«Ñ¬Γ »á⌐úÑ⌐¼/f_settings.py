import pygame
import sys
from f_load_image import load_image


def settings():
    # Функция, отвечающая за окно с настройками

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображения - выбор комнаты
    image_choice_level = load_image("menu/image_settings.png")
    image_choice_level = pygame.transform.scale(image_choice_level, size)

    # Создание непрозрачного прямоугольника для выхода в главное меню
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    pygame.display.set_caption('Settings')
    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        screen.blit(image_choice_level, (0, 0))
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            # Обработка изменения размера окна
            if event.type == pygame.VIDEORESIZE:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в главное меню
                        import main
                        main.main_menu()
        pygame.display.flip()
        clock.tick(fps)


settings()