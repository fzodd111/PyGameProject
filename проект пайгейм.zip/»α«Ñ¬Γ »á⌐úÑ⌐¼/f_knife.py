import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def knife():
    pygame.init()
    size = width, height = SIZE
    screen = SCREEN

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загружаем картинку
    import f_inventory
    image = f_inventory.inventory(3)[0]
    image_rect = pygame.Rect(width * 95.1 // 100, 0,
                             width * 5.8 // 100, height * 10.4 // 100)

    rect_pot = pygame.Rect(width * 45.3 // 100, height * 39 // 100,
                           width * 5.8 // 100, height * 10.4 // 100)

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    def background_image_and_dominoes_images():
        screen.blit(pygame.transform.scale(load_image("third_room/c_third_room.png"), size), (0, 0))
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        surface = pygame.Surface(rect_pot.size, pygame.SRCALPHA)
        surface.fill(color)
        screen.blit(surface, rect_pot.topleft)
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)

    background_image_and_dominoes_images()

    dragging = False

    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            # Начинаем перетаскивание при нажатии кнопки мыши
            if event.type == pygame.MOUSEBUTTONDOWN:
                if image_rect.collidepoint(event.pos):
                    dragging = True
                    offset_x = image_rect.x - event.pos[0]
                    offset_y = image_rect.y - event.pos[1]

            if button_main_menu_cr.collidepoint(event.pos):
                # Перемещение в 3 комнату
                import f_third_room
                f_third_room.third_room()

            # Останавливаем перетаскивание при отпускании кнопки мыши
            if event.type == pygame.MOUSEBUTTONUP:
                dragging = False

                if image_rect.colliderect(rect_pot):
                    SP.pop(3)
                    # Перемещение в окно с кодом для 3 комнаты
                    import f_code_third_room
                    f_code_third_room.code_third_room()

        # Перемещаем картинку, если перетаскиваем
        if dragging:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            image_rect.x = mouse_x + offset_x
            image_rect.y = mouse_y + offset_y

        # Заполняем экран и отображаем картинку
        background_image_and_dominoes_images()
        screen.blit(image, image_rect)

        pygame.display.flip()