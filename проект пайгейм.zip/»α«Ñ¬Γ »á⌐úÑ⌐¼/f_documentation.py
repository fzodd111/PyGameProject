import pygame
from f_load_image import load_image


def documentation():
    # Функция, отвечающая за окно с документацией

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Documentation")

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображения фона
    image_background = load_image("menu/documentation.png")
    image_background = pygame.transform.scale(image_background, size)

    # Создание непрозрачного прямоугольника для выхода в главное меню
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    # Начальные координаты квадрата
    square_x = width * 8.1 // 100
    square_y = height * 14.3 // 100
    square_width = width
    square_height = height

    # Скорость опускания квадрата
    speed_square = 0.5

    fps = 120
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                speed_square = 100
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в главное меню
                        import main
                        main.main_menu()

        # Изменение координат квадрата
        square_y += speed_square

        # Отрисовка
        screen.blit(image_background, (0, 0))
        pygame.draw.rect(screen, (0, 0, 0), (square_x, square_y, square_width, square_height))

        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)

        pygame.display.flip()
        clock.tick(fps)