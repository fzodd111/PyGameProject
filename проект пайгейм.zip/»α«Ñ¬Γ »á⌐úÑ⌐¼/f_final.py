import pygame
import sys
from f_load_image import load_image
from f_game_dominoes import SP_FRAGMENTS


def final():
    # Функция, отвечающая за окно с кодом для второй комнаты

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    im = pygame.transform.scale(load_image("menu/image_final.png"), (width, height))

    pygame.display.set_caption('Code')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()

        screen.blit(im, (0, 0))


        pygame.display.flip()
        clock.tick(fps)

final()