import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN
from f_sp_fragments import SP_KNIFE

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def knife_second_room():
    global SP, SIZE, SCREEN
    # Функция, отвечающая за окно с кодом для второй комнаты

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN
    color = (255, 0, 0, 0)
    # Загрузка изображения фона
    sp_images = [pygame.transform.scale(load_image("knife/background.png"), (width, height))]
    sp_positions_image = [(0, 0)]

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    pygame.display.set_caption('Knife')

    sp_button = [pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100),
                 pygame.Rect(width * 54.1 // 100, height * 45.5 // 100,
                             width * 3.6 // 100, height * 13 // 100)
                 ]

    fps = 30
    clock = pygame.time.Clock()
    if len(SP_KNIFE) == 0:
        flag = True
    else:
        flag = False

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_button[0].collidepoint(event.pos):
                        # Перемещение в главное меню
                        import f_second_room
                        f_second_room.second_room()
                    elif sp_button[1].collidepoint(event.pos):
                            # Взять нож
                            with open('count.txt', 'a') as f:
                                # Записываем данные
                                f.write('3')
                            SP_KNIFE.append(1)
                            flag = False
                            x = pygame.transform.scale(load_image("inventory/knife.png"), (width * 2.9 // 100,
                                                                                           height * 13 // 100))
                            y = pygame.Rect(width * 95.1 // 100, 0,
                                            width * 0.73 // 100, height * 1.3 // 100)
                            import f_inventory
                            f_inventory.inventory(2, x, y)

        screen.blit(sp_images[0], sp_positions_image[0])
        for i in sp_button:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)
        if flag:
            screen.blit(pygame.transform.scale(load_image("knife/knife.png"), (width * 2.9 // 100,
                                                                               height * 13.6 // 100)),
                        (width * 54.2 // 100, height * 45.4 // 100))

        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)


        pygame.display.flip()
        clock.tick(fps)