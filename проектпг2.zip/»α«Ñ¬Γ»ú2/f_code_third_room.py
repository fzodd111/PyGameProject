import pygame
import sys
from f_load_image import load_image


def code_third_room():
    # Функция, отвечающая за окно с кодом для второй комнаты

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    sp_images = [pygame.transform.scale(load_image("third_room/code_third_room.png"), (width, height))]
    sp_positions_image = [(0, 0)]
    screen.blit(sp_images[0], sp_positions_image[0])

    sp_transition = [pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
                     ]

    for i in sp_transition:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)
        screen.blit(surface, i.topleft)

    pygame.display.set_caption('Code')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_transition[0].collidepoint(event.pos):
                        # Перемещение в 3 комнату
                        import f_third_room
                        f_third_room.third_room()

        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)


        pygame.display.flip()
        clock.tick(fps)