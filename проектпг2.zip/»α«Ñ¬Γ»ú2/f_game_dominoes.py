import pygame
import sys
from random import randint as RD
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN
from f_sp_fragments import SP_FRAGMENTS

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def game_dominoes():
    global SP, SIZE, SCREEN
    # Функция, отвечающая за игру "домино"

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображения фона-стены
    im = load_image("first_room/4_1_dominoes.png")
    im = pygame.transform.scale(im, size)

    # Загрузка изображения фона-игры
    image_background = load_image("dominoes/background.png")
    image_background = pygame.transform.scale(image_background, (500, 500))

    # Загрузка изображений домино
    sp_image_dominoes = [pygame.transform.scale(load_image("dominoes/1.png"), (40, 80)),
                         pygame.transform.scale(load_image("dominoes/2.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/3.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/4.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/5.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/6.png"), (40, 80)),
                         pygame.transform.scale(load_image("dominoes/7.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/8.png"), (40, 80)),
                         pygame.transform.scale(load_image("dominoes/9.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/10.png"), (40, 80)),
                         pygame.transform.scale(load_image("dominoes/11.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/12.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/13.png"), (40, 80)),
                         pygame.transform.scale(load_image("dominoes/14.png"), (80, 40)),
                         pygame.transform.scale(load_image("dominoes/15.png"), (80, 40))]

    # Создание непрозрачных прямоугольников, для проверки местоположения домино
    x_game = (width - 500) // 2
    y_game = (height - 500) // 2
    sp_rectangle = [pygame.Rect(x_game + 125, y_game + 155, 10, 10), pygame.Rect(x_game + 185, y_game + 125, 10, 10),
                    pygame.Rect(x_game + 265, y_game + 125, 10, 10), pygame.Rect(x_game + 345, y_game + 125, 10, 10),
                    pygame.Rect(x_game + 385, y_game + 165, 10, 10), pygame.Rect(x_game + 365, y_game + 225, 10, 10),
                    pygame.Rect(x_game + 310, y_game + 325, 10, 10), pygame.Rect(x_game + 285, y_game + 270, 10, 10),
                    pygame.Rect(x_game + 310, y_game + 205, 10, 10), pygame.Rect(x_game + 365, y_game + 300, 10, 10),
                    pygame.Rect(x_game + 220, y_game + 205, 10, 10), pygame.Rect(x_game + 150, y_game + 205, 10, 10),
                    pygame.Rect(x_game + 125, y_game + 265, 10, 10), pygame.Rect(x_game + 150, y_game + 325, 10, 10),
                    pygame.Rect(x_game + 220, y_game + 325, 10, 10)]

    for i in sp_rectangle:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    def generate_random_positions(num_images):
        # Установление позиций для домино с помощью random

        positions = []
        for _ in range(num_images):
            x = RD(450, 450 + 500 - 80)
            y = RD(135, 135 + 500 - 80)
            positions.append((x, y))
        return positions

    def background_image_and_dominoes_images():
        # Отрисовка фона + начального положение домино

        screen.blit(im, (0, 0))
        screen.blit(image_background, ((width - 500) // 2, (height - 500) // 2))

        for i in range(15):
            screen.blit(sp_image_dominoes[i], sp_positions_image[i])

        sp_button = [pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                 width * 7.3 // 100, height * 3.9 // 100)
                     ]

        for i in sp_button:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

    def search_dominoes(x1, y1):
        # Фнкция, отвечающая за выявление домино на которую нажали

        for i in range(len(sp_positions_image)):
            x, y = sp_positions_image[i]
            if x <= x1 <= x + 80 and y <= y1 <= y + 80:
                return i

    def proverka():
        # Проверка находится ли домино на своем месте или нет

        if image_rect.colliderect(sp_rectangle[positions_now]):
            sp_proverka[positions_now] = True

        if not image_rect.colliderect(sp_rectangle[positions_now]):
            sp_proverka[positions_now] = False

        return sp_proverka

    def proverka_fragment():
        ...

    pygame.display.set_caption('Game dominoes')

    sp_button = [pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                             width * 7.3 // 100, height * 3.9 // 100)
                 ]

    fps = 30
    clock = pygame.time.Clock()

    drawing = False
    pos_dx, pos_dy = 0, 0
    sp_proverka = [False for _ in range(len(sp_rectangle))]

    sp_positions_image = generate_random_positions(15)
    background_image_and_dominoes_images()

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_button[0].collidepoint(event.pos):
                        # Перемещение в 1 комнату
                        import f_first_room
                        f_first_room.first_room()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Движение домино вслед за курсором
                x1, y1 = event.pos
                positions_now = search_dominoes(x1, y1)
                if None == positions_now:
                    break
                x0, y0 = sp_positions_image[positions_now]
                if x0 <= x1 <= x0 + 60 and y0 <= y1 <= y0 + 60:
                    drawing = True
                    pos_dx = x1 - x0
                    pos_dy = y1 - y0

                # Проверка нажатия на изображение
                image_rect = sp_image_dominoes[positions_now].get_rect(topleft=(x0, y0))
                if image_rect.collidepoint(event.pos):
                    drawing = True

            if event.type == pygame.MOUSEBUTTONUP:
                # Проверка возмножности перемещение домино
                if drawing:
                    drawing = False
                    image_rect = sp_image_dominoes[positions_now].get_rect(
                        topleft=(sp_positions_image[positions_now][0], sp_positions_image[positions_now][1]))
                    if all(proverka()):
                        # Взять фрагмент в инвентарь
                        SP_FRAGMENTS.append(1)
                        with open('count.txt', 'a') as f:
                            # Записываем данные
                            f.write('1')
                        x = pygame.transform.scale(load_image("fragment/1.png"), (width * 7.3 // 100,
                                                                                  height * 13.2 // 100))
                        y = pygame.Rect(width * 36.6 // 100, 0,
                                        width * 1.5 // 100, height * 2.6 // 100)
                        import f_inventory
                        f_inventory.inventory(3, x, y)
            if event.type == pygame.MOUSEMOTION:
                # Передвижение домино
                if drawing:
                    x1, y1 = event.pos
                    sp_positions_image[positions_now] = x1 - pos_dx, y1 - pos_dy
                    background_image_and_dominoes_images()
                    surface = pygame.Surface(i.size, pygame.SRCALPHA)
                    surface.fill(color)

        for i in sp_rectangle:
            screen.blit(surface, i.topleft)

        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)

        pygame.display.flip()
        clock.tick(fps)


game_dominoes()