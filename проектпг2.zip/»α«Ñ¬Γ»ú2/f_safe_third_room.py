import pygame
import sys
from f_load_image import load_image
from f_sp_fragments import SP_FRAGMENTS


def safe_third_room():
    # Функция, отвечающая за игру "домино"

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображения фона
    im = load_image("second_room/safe_2.png")
    im = pygame.transform.scale(im, size)

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    sp_rectangle = [pygame.Rect(width * 60.1 // 100, height * 47.7 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 56 // 100, height * 47.7 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 60.1 // 100, height * 55.1 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 64.4 // 100, height * 40.3 // 100,
                                width * 2.9 // 100, height * 4.8 // 100)]

    pygame.display.set_caption('Safe')

    fps = 30
    clock = pygame.time.Clock()

    screen.blit(im, (0, 0))
    c = ''

    # Основной цикл
    while True:
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)
        for i in sp_rectangle:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в 3 комнату
                        import f_third_room
                        f_third_room.third_room()
                    if sp_rectangle[0].collidepoint(event.pos):
                        c += '5'
                    elif sp_rectangle[1].collidepoint(event.pos):
                        c += '4'
                    elif sp_rectangle[2].collidepoint(event.pos):
                        c += '8'
                    elif sp_rectangle[3].collidepoint(event.pos):
                        c += '3'
                    else:
                        c = ''
                    if len(c) > 4:
                        c = ''
                    if c == '5483':
                        # Взять фрагмент в инвентарь
                        with open('count.txt', 'a') as f:
                            # Записываем данные
                            f.write('4')
                        SP_FRAGMENTS.append(1)
                        x = pygame.transform.scale(load_image("fragment/2.png"), (width * 7.3 // 100,
                                                                                  height * 13 // 100))
                        y = pygame.Rect(width * 43.9 // 100, 0,
                                        width * 2.9 // 100, height * 5.2 // 100)
                        import f_inventory
                        f_inventory.inventory(4, x, y)

        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)

        pygame.display.flip()
        clock.tick(fps)