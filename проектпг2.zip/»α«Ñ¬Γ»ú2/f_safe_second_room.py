import pygame
import sys
from f_load_image import load_image


def safe_second_room():
    # Функция, отвечающая за игру "домино"

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображения фона
    im = load_image("second_room/safe_2.png")
    im = pygame.transform.scale(im, size)

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    sp_rectangle = [pygame.Rect(width * 64.4 // 100, height * 40.3 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 56 // 100, height * 40.3 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 60.1 // 100, height * 47.7 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 56 // 100, height * 47.7 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 64.4 // 100, height * 47.7 // 100,
                                width * 2.9 // 100, height * 4.8 // 100),
                    pygame.Rect(width * 60.1 // 100, height * 40.3 // 100,
                                width * 2.9 // 100, height * 4.8 // 100)]

    pygame.display.set_caption('Safe')

    fps = 30
    clock = pygame.time.Clock()

    screen.blit(im, (0, 0))
    c = ''

    # Основной цикл
    while True:
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)
        for i in sp_rectangle:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в главное меню
                        import f_second_room
                        f_second_room.second_room()
                    if sp_rectangle[0].collidepoint(event.pos):
                        c += '3'
                    elif sp_rectangle[1].collidepoint(event.pos):
                        c += '1'
                    elif sp_rectangle[2].collidepoint(event.pos):
                        c += '5'
                    elif sp_rectangle[3].collidepoint(event.pos):
                        c += '4'
                    elif sp_rectangle[4].collidepoint(event.pos):
                        c += '6'
                    elif sp_rectangle[5].collidepoint(event.pos):
                        c += '2'
                    else:
                        c = ''
                    if len(c) > 6:
                        c = ''
                    if c == '315462':
                        import f_not_eclipse
                        f_not_eclipse.not_eclipse_sr()

        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])


        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)

        pygame.display.flip()
        clock.tick(fps)