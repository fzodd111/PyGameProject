import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN
from f_sp_fragments import SP_FRAGMENTS

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def matches():

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN

    # Цвет для областей нажатия
    color = (255, 0, 0, 123)

    # Загружаем картинку
    import f_inventory
    image = f_inventory.inventory(2)[0]
    image_rect = pygame.Rect(width * 88.9 // 100, 0,
                             width * 5.8 // 100, height * 10.4 // 100)

    # Загрузка изображений
    sp_images_arrow = [pygame.transform.scale(load_image("arrow/arrow_left.png"), (50, 50)),
                       pygame.transform.scale(load_image("arrow/arrow_right.png"), (50, 50))]

    rect_pot = pygame.Rect(width * 54.9 // 100, height * 45.5 // 100,
                           width * 10.9 // 100, height * 19.5 // 100)

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 54.9 // 100, 400,
                           width * 10.9 // 100, height * 19.5 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    def background_image_and_dominoes_images():
        screen.blit(pygame.transform.scale(load_image("third_room/4_3.png"), size), (0, 0))
        screen.blit(pygame.transform.scale(load_image("third_room/pot.png"), (width * 16.8 // 100,
                                                                              height * 16.9 // 100)),
                    (width * 49.7 // 100, height * 46.8 // 100))
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(sp_images_arrow[0], (0, (height - 50) // 2))
        screen.blit(sp_images_arrow[1], (width - 50, (height - 50) // 2))

        surface = pygame.Surface(rect_pot.size, pygame.SRCALPHA)
        surface.fill(color)
        screen.blit(surface, rect_pot.topleft)
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)

    background_image_and_dominoes_images()

    dragging = False

    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            # Начинаем перетаскивание при нажатии кнопки мыши
            if event.type == pygame.MOUSEBUTTONDOWN:
                if image_rect.collidepoint(event.pos):
                    dragging = True
                    offset_x = image_rect.x - event.pos[0]
                    offset_y = image_rect.y - event.pos[1]

            if button_main_menu_cr.collidepoint(event.pos):
                # Перемещение в 3 комнату
                import f_third_room
                f_third_room.third_room()

            # Останавливаем перетаскивание при отпускании кнопки мыши
            if event.type == pygame.MOUSEBUTTONUP:
                dragging = False

                if image_rect.colliderect(rect_pot):
                    SP.pop(2)
                    SP_FRAGMENTS.append(1)
                    # Взять фрагмент в инвентарь
                    with open('count.txt', 'a') as f:
                        # Записываем данные
                        f.write('5')
                    x = pygame.transform.scale(load_image("fragment/3.png"), (width * 7.3 // 100,
                                                                              height * 13 // 100))
                    y = pygame.Rect(width * 58.5 // 100, 0,
                                    width * 2.9 // 100, height * 5.2 // 100)
                    f_inventory.inventory(5, x, y)

        # Перемещаем картинку, если перетаскиваем
        if dragging:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            image_rect.x = mouse_x + offset_x
            image_rect.y = mouse_y + offset_y

        # Заполняем экран и отображаем картинку
        background_image_and_dominoes_images()
        screen.blit(image, image_rect)
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        # Создание текста
        with open('count.txt', 'r') as f:
            data = f.read().replace('\n', '')
        data1 = '0' + data
        text_color = (255, 255, 255)
        font = pygame.font.Font(None, 40)
        text_surface1 = font.render('', True, text_color)
        text_surface2 = font.render(f'{data1[-1]}/5', True, text_color)
        text_rect = (90, height * 2.6 // 100,
                 width * 7.3 // 100, height * 3.9 // 100)
        screen.blit(text_surface1, text_rect)
        screen.blit(text_surface2, text_rect)


        pygame.display.flip()