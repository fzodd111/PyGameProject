import pygame
import sys
from f_load_image import load_image


def not_eclipse_sr ():
    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Создание непрозрачного прямоугольника для выхода в комнату
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    # Цвета
    black = (0, 0, 0)

    # Начальная прозрачность
    alpha = 255
    fade_speed = 5  # Скорость растемнения

    pygame.display.set_caption('Not darkening the screen')

    # Основной цикл
    while True:
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в главное меню
                        import f_second_room
                        f_second_room.second_room()

                # Уменьшение прозрачности
                if alpha > 0:
                    alpha -= fade_speed  # Уменьшаем прозрачность

        # Создание поверхности для затемнения
        dark_surface = pygame.Surface((width, height))
        dark_surface.fill(black)
        dark_surface.set_alpha(alpha)  # Установка прозрачности

        # Отрисовка затемняющего слоя
        screen.blit(dark_surface, (0, 0))
        pygame.time.delay(30)

        sp_images = [pygame.transform.scale(load_image("second_room/image_knife.png"), (width, height))]
        sp_positions_image = [(0, 0)]
        screen.blit(sp_images[0], sp_positions_image[0])

        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)

        pygame.display.flip()