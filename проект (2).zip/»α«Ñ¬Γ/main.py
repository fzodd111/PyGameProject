import pygame
import sys
from f_load_image import load_image


def main_menu():
    # Функция, отвечающая за главное меню

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 123)

    # Загрузка начального изображения
    image_start_background = load_image("menu/menu.png")
    image_start_background = pygame.transform.scale(image_start_background, size)

    # Создание непрозрачных прямоугольников для кнопок на начальном экране
    sp_button = [pygame.Rect(width * 41 // 100, height * 61.1 // 100, width * 20.4 // 100, height * 10.4 // 100),
                 pygame.Rect(width * 41 // 100, height * 44.2 // 100, width * 20.4 // 100, height * 10.4 // 100),
                 pygame.Rect(width * 41 // 100, height * 26.6 // 100, width * 20.4 // 100, height * 10.4 // 100)]

    for i in sp_button:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    pygame.display.set_caption('Main menu')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        # Отображение фона
        screen.blit(image_start_background, (0, 0))
        for i in sp_button:
            screen.blit(surface, i.topleft)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_button[0].collidepoint(event.pos):
                        # Перемещение для выбра комнаты
                        import f_choice_level
                        f_choice_level.choice_level()

                    if sp_button[1].collidepoint(event.pos):
                        # Перемещение в настройки
                        ...
                    if sp_button[2].collidepoint(event.pos):
                        # Перемещение в документацию
                        import f_documentation
                        f_documentation.documentation()

        pygame.display.flip()
        clock.tick(fps)


main_menu()