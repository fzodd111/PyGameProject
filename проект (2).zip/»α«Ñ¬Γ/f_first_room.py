import pygame
import sys
from f_load_image import load_image


def first_room():
    # Функция, отвечающая за 1 комнату

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 123)

    # Загрузка изображений стен
    sp_images_walls = [pygame.transform.scale(load_image("first_room/1_1.png"), size),
                       pygame.transform.scale(load_image("first_room/2_1.png"), size),
                       pygame.transform.scale(load_image("first_room/4_1.png"), size),
                       pygame.transform.scale(load_image("first_room/3_1.png"), size)]
    # Индекс и список, отвечающий за фон
    index_wall = 0
    background = sp_images_walls[index_wall]

    # Индекс и список, отвечающий за номер фона
    sp_number_wall = [1, 2, 3, 4]
    background_number = sp_number_wall[index_wall]

    # Загрузка изображений стрелок
    sp_images_arrow = [pygame.transform.scale(load_image("arrow/arrow_left.png"), (50, 50)),
                       pygame.transform.scale(load_image("arrow/arrow_right.png"), (50, 50))]

    # Создание непрозрачных прямоугольников для стрелок
    sp_rectangle_arrow = [pygame.Rect(10, (height - 50) // 2, 30, 50),
                          pygame.Rect(width - 40, (height - 50) // 2, 30, 50)]

    for i in sp_rectangle_arrow:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    def fourth_wall():
        # Функция, отвечающая за действия на 4 стене

        rect_game_dominoes = pygame.Rect(width * 53.8 // 100, height * 17.5 // 100,
                                         width * 6.5 // 100, height * 10.4 // 100)
        surface_game_dominoes = pygame.Surface(rect_game_dominoes.size, pygame.SRCALPHA)
        surface_game_dominoes.fill(color)

        # Отображение области для перемещение в игру "домино"
        screen.blit(surface_game_dominoes, rect_game_dominoes.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if rect_game_dominoes.collidepoint(event.pos):
                    # Перемещение в игру "домино"
                    import f_game_dominoes
                    f_game_dominoes.game_dominoes()

    pygame.display.set_caption('Room')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    # Смена стен в левую сторону
                    if sp_rectangle_arrow[0].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall - 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall - 1) % len(sp_number_wall)]
                        index_wall -= 1
                    # Смена стен в правую сторону
                    if sp_rectangle_arrow[1].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall + 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall + 1) % len(sp_number_wall)]
                        index_wall += 1

        # Отображение стены
        screen.blit(background, (0, 0))
        if background_number == 0:
            # Переход к функции, отвечающей за 1 стену

            ...
        elif background_number == 1:
            # Переход к функции, отвечающей за 2 стену

            ...
        elif background_number == 2:
            # Переход к функции, отвечающей за 3 стену

            ...
        elif background_number == 3:
            # Переход к функции, отвечающей за 4 стену
            fourth_wall()

        # Отображение изображений стрелок
        screen.blit(sp_images_arrow[0], (0, (height - 50) // 2))
        screen.blit(sp_images_arrow[1], (width - 50, (height - 50) // 2))

        # Отображение области для обработки нажатия на стрелку
        for i in sp_rectangle_arrow:
            screen.blit(surface, i.topleft)

        pygame.display.flip()
        clock.tick(fps)


first_room()