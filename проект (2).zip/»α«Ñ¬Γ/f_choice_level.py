import pygame
import sys
from f_load_image import load_image


def choice_level():
    # Функция, отвечающая за окно с выбором комнаты

    pygame.init()
    size = width, height = 1366, 768
    screen = pygame.display.set_mode(size)

    # Цвет для областей нажатия
    color = (255, 0, 0, 128)

    # Загрузка изображения - выбор комнаты
    image_choice_level = load_image("menu/choice.png")
    image_choice_level = pygame.transform.scale(image_choice_level, size)

    # Создание непрозрачного прямоугольника для выхода в главное меню
    button_main_menu_cr = pygame.Rect(width * 1.4 // 100, height * 2.6 // 100,
                                      width * 7.3 // 100, height * 3.9 // 100)
    surface_main_menu_cr = pygame.Surface(button_main_menu_cr.size, pygame.SRCALPHA)
    surface_main_menu_cr.fill(color)

    # Создание непрозрачного прямоугольников для выбора комнаты
    sp_button_room = [pygame.Rect(width * 5.8 // 100,  height * 20.8 // 100,
                                  width * 21 // 100, height * 52 // 100),
                      pygame.Rect(width * 39 // 100, height * 20.8 // 100,
                                  width * 21 // 100, height * 52 // 100),
                      pygame.Rect(width * 74 // 100, height * 20.8 // 100,
                                  width * 21 // 100, height * 52 // 100)]

    for i in sp_button_room:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    pygame.display.set_caption('Choice room')
    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        screen.blit(image_choice_level, (0, 0))
        for i in sp_button_room:
            screen.blit(surface, i.topleft)
        screen.blit(surface_main_menu_cr, button_main_menu_cr.topleft)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if sp_button_room[0].collidepoint(event.pos):
                        # Перемещение в первую комнату
                        import f_first_room
                        f_first_room.first_room()
                    if sp_button_room[1].collidepoint(event.pos):
                        # Перемещение во вторую комнату
                        ...
                    if sp_button_room[2].collidepoint(event.pos):
                        # Перемещение в третью комнату
                        ...
                    if button_main_menu_cr.collidepoint(event.pos):
                        # Перемещение в главное меню
                        import main
                        main.main_menu()

        pygame.display.flip()
        clock.tick(fps)


choice_level()