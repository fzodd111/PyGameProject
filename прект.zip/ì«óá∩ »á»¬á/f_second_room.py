import pygame
import sys
from f_load_image import load_image
from f_inventory import SP, SIZE, SCREEN

SP, SIZE, SCREEN = SP, SIZE, SCREEN


def second_room():
    global SP, SIZE, SCREEN
    # Функция, отвечающая за вторую комнату

    pygame.init()
    size = width, height = SIZE
    screen = SCREEN

    # Цвет для областей нажатия
    color = (255, 0, 0, 0)

    # Загрузка изображений стен
    sp_images_walls = [pygame.transform.scale(load_image("second_room/3_2.png"), size),
                       pygame.transform.scale(load_image("second_room/1_2.png"), size),
                       pygame.transform.scale(load_image("second_room/2_2.png"), size),
                       pygame.transform.scale(load_image("second_room/4_2.png"), size)]

    # Индекс и список, отвечающий за фон
    index_wall = 0
    background = sp_images_walls[index_wall]

    # Индекс и список, отвечающий за номер фона
    sp_number_wall = [0, 1, 2, 3]
    background_number = sp_number_wall[index_wall]

    # Загрузка изображений стрелок
    sp_images_arrow = [pygame.transform.scale(load_image("arrow/arrow_left.png"), (50, 50)),
                       pygame.transform.scale(load_image("arrow/arrow_right.png"), (50, 50))]

    # Создание непрозрачных прямоугольников для стрелок
    sp_rectangle_arrow = [pygame.Rect(10, (height - 50) // 2, 30, 50),
                          pygame.Rect(width - 40, (height - 50) // 2, 30, 50)]

    for i in sp_rectangle_arrow:
        surface = pygame.Surface(i.size, pygame.SRCALPHA)
        surface.fill(color)

    def zero_wall():
        sp_transition = [pygame.Rect(width * 43.9 // 100, height * 24 // 100,
                                     width * 17.6 // 100, height * 20.1 // 100)]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение для взятия ножа
                    import f_knife_second_room
                    f_knife_second_room.knife_second_room()

    def first_wall():
        # Функция, отвечающая за действия на 1 стене

        sp_transition = [pygame.Rect(width * 71 // 100, height * 58.5 // 100,
                                     width * 9.5 // 100, height * 15.6 // 100),
                         pygame.Rect(width * 18.3 // 100, height * 65 // 100,
                                     width * 16.8 // 100, height * 14.3 // 100)
                         ]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение в окно с сейфом для второй комнаты
                    import f_safe_second_room
                    f_safe_second_room.safe_second_room()
                if sp_transition[1].collidepoint(event.pos):
                    # Перемещение в окно с ящиком для второй комнаты
                    import f_box_second_room
                    f_box_second_room.box_second_room()

    def second_wall():
        # Функция, отвечающая за действия на 1 стене

        sp_transition = [pygame.Rect(width * 65.5 // 100, height * 16.9 // 100,
                                     width * 21.5 // 100, height * 26.6 // 100)]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение в окно c кодом для второй комнаты
                    import f_code_second_room
                    f_code_second_room.code_second_room()

    def third_wall():
        # Функция, отвечающая за действия на 3 стене
        sp_transition = [pygame.Rect(width * 74.6 // 100, height * 29.2 // 100,
                                     width * 6.9 // 100, height * 15.6 // 100)
                         ]

        for i in sp_transition:
            surface = pygame.Surface(i.size, pygame.SRCALPHA)
            surface.fill(color)
            screen.blit(surface, i.topleft)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sp_transition[0].collidepoint(event.pos):
                    # Перемещение в окно "выбор комнат"
                    import f_choice_level
                    f_choice_level.choice_level()

    pygame.display.set_caption('Room')

    fps = 30
    clock = pygame.time.Clock()

    # Основной цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Выход из игры
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    # Смена стен в левую сторону
                    if sp_rectangle_arrow[0].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall - 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall - 1) % len(sp_number_wall)]
                        index_wall -= 1
                    # Смена стен в правую сторону
                    if sp_rectangle_arrow[1].collidepoint(event.pos):
                        background = sp_images_walls[(index_wall + 1) % len(sp_images_walls)]
                        background_number = sp_number_wall[(index_wall + 1) % len(sp_number_wall)]
                        index_wall += 1

        # Отображение стены
        screen.blit(background, (0, 0))
        import f_inventory
        screen.blit(f_inventory.inventory(1)[0], f_inventory.inventory(1)[1])
        screen.blit(f_inventory.inventory(2)[0], f_inventory.inventory(2)[1])
        screen.blit(f_inventory.inventory(3)[0], f_inventory.inventory(3)[1])
        screen.blit(f_inventory.inventory(4)[0], f_inventory.inventory(4)[1])
        screen.blit(f_inventory.inventory(5)[0], f_inventory.inventory(5)[1])

        if background_number == 0:
            # Переход к функции, отвечающей за 0 стену
            zero_wall()

        elif background_number == 1:
            # Переход к функции, отвечающей за 1 стену
            first_wall()

        elif background_number == 2:
            second_wall()
            # Переход к функции, отвечающей за 2 стене

        elif background_number == 3:
            # Переход к функции, отвечающей за 3 стену
            third_wall()

        # Отображение изображений стрелок
        screen.blit(sp_images_arrow[0], (0, (height - 50) // 2))
        screen.blit(sp_images_arrow[1], (width - 50, (height - 50) // 2))

        # Отображение области для обработки нажатия на стрелку
        for i in sp_rectangle_arrow:
            screen.blit(surface, i.topleft)

        pygame.display.flip()
        clock.tick(fps)


second_room()